Create Java version test:

javac -target 5 -source 5 Test.java
jar cfe test.jar Test Test.class
